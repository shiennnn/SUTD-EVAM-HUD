/*******************************************************************************
 * Size: 16 px
 * Bpp: 1
 * Opts: --bpp 1 --size 16 --font C:/Users/sherl/SquareLine/assets/Exo2-VariableFont_wght.ttf -o C:/Users/sherl/SquareLine/assets\ui_font_Font16.c --format lvgl -r 0x20-0x7f --no-compress --no-prefilter
 ******************************************************************************/

#include "ui.h"

#ifndef UI_FONT_FONT16
#define UI_FONT_FONT16 1
#endif

#if UI_FONT_FONT16

/*-----------------
 *    BITMAPS
 *----------------*/

/*Store the image of the glyphs*/
static LV_ATTRIBUTE_LARGE_CONST const uint8_t glyph_bitmap[] = {
    /* U+0020 " " */
    0x0,

    /* U+0021 "!" */
    0xff, 0x60,

    /* U+0022 "\"" */
    0xb6, 0x80,

    /* U+0023 "#" */
    0x11, 0x8, 0x8c, 0xdf, 0xf2, 0x21, 0x10, 0x89,
    0xfe, 0x66, 0x22, 0x11, 0x0,

    /* U+0024 "$" */
    0x8, 0x21, 0xfc, 0x89, 0x12, 0x3c, 0x3e, 0x16,
    0x24, 0x48, 0x9f, 0xc4, 0x8, 0x0,

    /* U+0025 "%" */
    0x70, 0x44, 0x42, 0x22, 0x21, 0x12, 0x8, 0x90,
    0x39, 0x38, 0x12, 0x20, 0x91, 0x8, 0x88, 0x84,
    0x44, 0x1c,

    /* U+0026 "&" */
    0x3e, 0x10, 0x4, 0x1, 0x4, 0x41, 0xf, 0xfc,
    0x12, 0x4, 0x81, 0x20, 0xc7, 0xdc,

    /* U+0027 "'" */
    0xe0,

    /* U+0028 "(" */
    0x12, 0x44, 0x88, 0x88, 0x88, 0x88, 0x44, 0x21,

    /* U+0029 ")" */
    0x84, 0x22, 0x11, 0x11, 0x11, 0x11, 0x22, 0x48,

    /* U+002A "*" */
    0x21, 0x3e, 0xa5, 0x0,

    /* U+002B "+" */
    0x10, 0x20, 0x47, 0xf1, 0x2, 0x4, 0x0,

    /* U+002C "," */
    0xf0,

    /* U+002D "-" */
    0xf8,

    /* U+002E "." */
    0xc0,

    /* U+002F "/" */
    0x3, 0x2, 0x6, 0x4, 0x8, 0x8, 0x10, 0x10,
    0x20, 0x20, 0x40, 0x40,

    /* U+0030 "0" */
    0x38, 0x8a, 0xc, 0x18, 0x30, 0x60, 0xc1, 0x82,
    0x88, 0xe0,

    /* U+0031 "1" */
    0x3f, 0x11, 0x11, 0x11, 0x11, 0x10,

    /* U+0032 "2" */
    0xfc, 0x4, 0x8, 0x10, 0x41, 0x86, 0x18, 0x61,
    0x83, 0xf8,

    /* U+0033 "3" */
    0xf8, 0x10, 0x41, 0x78, 0x30, 0x41, 0x4, 0x3f,
    0x80,

    /* U+0034 "4" */
    0x18, 0x10, 0x32, 0x22, 0x62, 0x42, 0xc2, 0xff,
    0x2, 0x2, 0x2,

    /* U+0035 "5" */
    0x7e, 0x81, 0x2, 0x7, 0x81, 0xc0, 0x81, 0x2,
    0xf, 0xf0,

    /* U+0036 "6" */
    0x3c, 0x82, 0x4, 0xb, 0xd8, 0xe0, 0xc1, 0x83,
    0x8d, 0xf0,

    /* U+0037 "7" */
    0xfe, 0xc, 0x10, 0x20, 0xc1, 0x2, 0xc, 0x10,
    0x20, 0xc0,

    /* U+0038 "8" */
    0x7d, 0x6, 0xc, 0x18, 0x2f, 0xb0, 0xc1, 0x83,
    0x5, 0xf0,

    /* U+0039 "9" */
    0x7d, 0x8e, 0xc, 0x18, 0x38, 0xde, 0x81, 0x2,
    0xb, 0xe0,

    /* U+003A ":" */
    0xc6,

    /* U+003B ";" */
    0xc7, 0x80,

    /* U+003C "<" */
    0x6, 0x33, 0x86, 0x3, 0x1, 0xc0, 0x80,

    /* U+003D "=" */
    0xfe, 0x0, 0x7, 0xf0,

    /* U+003E ">" */
    0x80, 0xe0, 0x30, 0x33, 0x98, 0x0, 0x0,

    /* U+003F "?" */
    0xfc, 0x4, 0x8, 0x10, 0x41, 0x4, 0x8, 0x0,
    0x20, 0x40,

    /* U+0040 "@" */
    0x7f, 0x60, 0x60, 0x33, 0xf9, 0xc, 0x8e, 0x7b,
    0x0, 0xc0, 0x3f, 0xc0,

    /* U+0041 "A" */
    0xc, 0x7, 0x81, 0x20, 0x48, 0x33, 0x8, 0x43,
    0xf1, 0x86, 0x40, 0x90, 0x3c, 0xc,

    /* U+0042 "B" */
    0xfd, 0x6, 0xc, 0x18, 0x3f, 0xa1, 0xc1, 0x83,
    0x7, 0xf0,

    /* U+0043 "C" */
    0x3e, 0x82, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80,
    0x80, 0xf8,

    /* U+0044 "D" */
    0xfc, 0x82, 0x81, 0x81, 0x81, 0x81, 0x81, 0x81,
    0x81, 0x82, 0xfc,

    /* U+0045 "E" */
    0x7e, 0x8, 0x20, 0x83, 0xf8, 0x20, 0x82, 0x7,
    0xc0,

    /* U+0046 "F" */
    0x7e, 0x8, 0x20, 0x83, 0xf8, 0x20, 0x82, 0x8,
    0x0,

    /* U+0047 "G" */
    0x3f, 0x40, 0x80, 0x80, 0x80, 0x81, 0x81, 0x81,
    0x81, 0x43, 0x3d,

    /* U+0048 "H" */
    0x81, 0x81, 0x81, 0x81, 0x81, 0xff, 0x81, 0x81,
    0x81, 0x81, 0x81,

    /* U+0049 "I" */
    0xff, 0xe0,

    /* U+004A "J" */
    0x24, 0x92, 0x49, 0x27, 0x0,

    /* U+004B "K" */
    0x82, 0x84, 0x8c, 0x98, 0x90, 0xf0, 0x98, 0x88,
    0x8c, 0x86, 0x82,

    /* U+004C "L" */
    0x81, 0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x81,
    0x1, 0xf8,

    /* U+004D "M" */
    0xe0, 0xf4, 0x16, 0x82, 0xd8, 0xd9, 0x13, 0x22,
    0x66, 0xcc, 0x51, 0x8a, 0x31, 0xc6, 0x0, 0x80,

    /* U+004E "N" */
    0xc1, 0xe1, 0xa1, 0xb1, 0x91, 0x99, 0x89, 0x8d,
    0x85, 0x87, 0x87,

    /* U+004F "O" */
    0x3c, 0x42, 0x81, 0x81, 0x81, 0x81, 0x81, 0x81,
    0x81, 0x42, 0x3c,

    /* U+0050 "P" */
    0xfd, 0xe, 0xc, 0x18, 0x30, 0xff, 0x40, 0x81,
    0x2, 0x0,

    /* U+0051 "Q" */
    0x3c, 0x42, 0x81, 0x81, 0x81, 0x81, 0x81, 0x81,
    0x81, 0x42, 0x3c, 0x0, 0x1e, 0x6,

    /* U+0052 "R" */
    0xfd, 0x6, 0xc, 0x18, 0x3f, 0x21, 0x43, 0x83,
    0x6, 0x8,

    /* U+0053 "S" */
    0x7f, 0x2, 0x4, 0xe, 0xf, 0x81, 0x81, 0x2,
    0x7, 0xf0,

    /* U+0054 "T" */
    0xff, 0x84, 0x2, 0x1, 0x0, 0x80, 0x40, 0x20,
    0x10, 0x8, 0x4, 0x2, 0x0,

    /* U+0055 "U" */
    0x81, 0x81, 0x81, 0x81, 0x81, 0x81, 0x81, 0x81,
    0x81, 0x42, 0x3c,

    /* U+0056 "V" */
    0xc0, 0xa0, 0x50, 0x6c, 0x22, 0x11, 0x18, 0xc8,
    0x24, 0x16, 0xe, 0x3, 0x0,

    /* U+0057 "W" */
    0x43, 0x86, 0x85, 0x9, 0xa, 0x13, 0x16, 0x66,
    0x6c, 0xc4, 0xc9, 0x89, 0x12, 0x12, 0x24, 0x34,
    0x78, 0x38, 0x70, 0x60, 0xc0,

    /* U+0058 "X" */
    0x41, 0x31, 0x88, 0x86, 0xc1, 0x40, 0xe0, 0x50,
    0x6c, 0x22, 0x31, 0x90, 0x40,

    /* U+0059 "Y" */
    0x41, 0x31, 0x88, 0x86, 0xc1, 0x40, 0xa0, 0x20,
    0x10, 0x8, 0x4, 0x2, 0x0,

    /* U+005A "Z" */
    0xff, 0x3, 0x6, 0xc, 0x8, 0x18, 0x30, 0x20,
    0x60, 0xc0, 0xff,

    /* U+005B "[" */
    0xf2, 0x49, 0x24, 0x92, 0x49, 0x38,

    /* U+005C "\\" */
    0x40, 0x40, 0x20, 0x20, 0x10, 0x10, 0x8, 0xc,
    0x4, 0x6, 0x2, 0x3,

    /* U+005D "]" */
    0xe4, 0x92, 0x49, 0x24, 0x92, 0x78,

    /* U+005E "^" */
    0x10, 0xa4, 0x40,

    /* U+005F "_" */
    0xfe,

    /* U+0060 "`" */
    0x19, 0x80,

    /* U+0061 "a" */
    0xfc, 0x4, 0xb, 0xf8, 0x30, 0x61, 0xbd,

    /* U+0062 "b" */
    0x81, 0x2, 0x5, 0xec, 0x70, 0x60, 0xc1, 0x83,
    0xf, 0xf0,

    /* U+0063 "c" */
    0x7f, 0x8, 0x20, 0x82, 0xc, 0x1f,

    /* U+0064 "d" */
    0x2, 0x4, 0xb, 0xfc, 0x30, 0x60, 0xc1, 0x83,
    0x8d, 0xe8,

    /* U+0065 "e" */
    0x7d, 0x86, 0xc, 0x1f, 0xd0, 0x30, 0x3f,

    /* U+0066 "f" */
    0x3a, 0x11, 0xf4, 0x21, 0x8, 0x42, 0x10,

    /* U+0067 "g" */
    0x7f, 0x6, 0xc, 0x17, 0xd0, 0x3e, 0x67, 0x83,
    0x5, 0xf0,

    /* U+0068 "h" */
    0x81, 0x2, 0x5, 0xee, 0x30, 0x60, 0xc1, 0x83,
    0x6, 0x8,

    /* U+0069 "i" */
    0xdf, 0xe0,

    /* U+006A "j" */
    0x51, 0x55, 0x55, 0x60,

    /* U+006B "k" */
    0x81, 0x2, 0x4, 0x28, 0x93, 0x3c, 0x48, 0x99,
    0x1a, 0x18,

    /* U+006C "l" */
    0x92, 0x49, 0x24, 0x93, 0x80,

    /* U+006D "m" */
    0xb9, 0xd8, 0xc6, 0x10, 0xc2, 0x18, 0x43, 0x8,
    0x61, 0xc, 0x21,

    /* U+006E "n" */
    0xbd, 0xc6, 0xc, 0x18, 0x30, 0x60, 0xc1,

    /* U+006F "o" */
    0x7d, 0x8e, 0xc, 0x18, 0x30, 0x71, 0xbe,

    /* U+0070 "p" */
    0xbd, 0x8e, 0xc, 0x18, 0x30, 0x61, 0xfe, 0x81,
    0x2, 0x0,

    /* U+0071 "q" */
    0x7f, 0x86, 0xc, 0x18, 0x30, 0x71, 0xbd, 0x2,
    0x4, 0x8,

    /* U+0072 "r" */
    0xb6, 0x21, 0x8, 0x42, 0x10,

    /* U+0073 "s" */
    0x7e, 0x8, 0x3c, 0x3c, 0x10, 0x7e,

    /* U+0074 "t" */
    0x44, 0x4f, 0x44, 0x44, 0x44, 0x30,

    /* U+0075 "u" */
    0x86, 0x18, 0x61, 0x86, 0x18, 0xdd,

    /* U+0076 "v" */
    0xc1, 0x43, 0x62, 0x22, 0x26, 0x34, 0x1c, 0x18,

    /* U+0077 "w" */
    0x47, 0x1a, 0x28, 0x99, 0x44, 0xca, 0x62, 0xda,
    0x14, 0x50, 0xe2, 0x83, 0x1c,

    /* U+0078 "x" */
    0xc4, 0x88, 0xa0, 0x82, 0x8d, 0x91, 0x63,

    /* U+0079 "y" */
    0xc3, 0x43, 0x62, 0x26, 0x24, 0x34, 0x1c, 0x18,
    0x8, 0x10, 0x20,

    /* U+007A "z" */
    0xfe, 0xc, 0x30, 0xc3, 0xc, 0x30, 0x7f,

    /* U+007B "{" */
    0x24, 0x44, 0x44, 0xcc, 0x44, 0x44, 0x44, 0x30,

    /* U+007C "|" */
    0xff, 0xfe,

    /* U+007D "}" */
    0x84, 0x44, 0x44, 0x67, 0x44, 0x44, 0x44, 0x80,

    /* U+007E "~" */
    0xe6, 0x70
};


/*---------------------
 *  GLYPH DESCRIPTION
 *--------------------*/

static const lv_font_fmt_txt_glyph_dsc_t glyph_dsc[] = {
    {.bitmap_index = 0, .adv_w = 0, .box_w = 0, .box_h = 0, .ofs_x = 0, .ofs_y = 0} /* id = 0 reserved */,
    {.bitmap_index = 0, .adv_w = 57, .box_w = 1, .box_h = 1, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1, .adv_w = 70, .box_w = 1, .box_h = 11, .ofs_x = 2, .ofs_y = 0},
    {.bitmap_index = 3, .adv_w = 90, .box_w = 3, .box_h = 3, .ofs_x = 1, .ofs_y = 8},
    {.bitmap_index = 5, .adv_w = 175, .box_w = 9, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 18, .adv_w = 144, .box_w = 7, .box_h = 15, .ofs_x = 1, .ofs_y = -2},
    {.bitmap_index = 32, .adv_w = 229, .box_w = 13, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 50, .adv_w = 198, .box_w = 10, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 64, .adv_w = 54, .box_w = 1, .box_h = 3, .ofs_x = 1, .ofs_y = 8},
    {.bitmap_index = 65, .adv_w = 92, .box_w = 4, .box_h = 16, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 73, .adv_w = 92, .box_w = 4, .box_h = 16, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 81, .adv_w = 115, .box_w = 5, .box_h = 5, .ofs_x = 1, .ofs_y = 6},
    {.bitmap_index = 85, .adv_w = 141, .box_w = 7, .box_h = 7, .ofs_x = 1, .ofs_y = 1},
    {.bitmap_index = 92, .adv_w = 58, .box_w = 1, .box_h = 4, .ofs_x = 1, .ofs_y = -2},
    {.bitmap_index = 93, .adv_w = 115, .box_w = 5, .box_h = 1, .ofs_x = 1, .ofs_y = 4},
    {.bitmap_index = 94, .adv_w = 59, .box_w = 1, .box_h = 2, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 95, .adv_w = 132, .box_w = 8, .box_h = 12, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 107, .adv_w = 154, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 117, .adv_w = 102, .box_w = 4, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 123, .adv_w = 144, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 133, .adv_w = 142, .box_w = 6, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 142, .adv_w = 157, .box_w = 8, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 153, .adv_w = 137, .box_w = 7, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 163, .adv_w = 146, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 173, .adv_w = 131, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 183, .adv_w = 155, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 193, .adv_w = 146, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 203, .adv_w = 60, .box_w = 1, .box_h = 7, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 204, .adv_w = 61, .box_w = 1, .box_h = 9, .ofs_x = 1, .ofs_y = -2},
    {.bitmap_index = 206, .adv_w = 136, .box_w = 7, .box_h = 7, .ofs_x = 1, .ofs_y = 1},
    {.bitmap_index = 213, .adv_w = 150, .box_w = 7, .box_h = 4, .ofs_x = 1, .ofs_y = 3},
    {.bitmap_index = 217, .adv_w = 136, .box_w = 7, .box_h = 7, .ofs_x = 1, .ofs_y = 1},
    {.bitmap_index = 224, .adv_w = 129, .box_w = 7, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 234, .adv_w = 184, .box_w = 9, .box_h = 10, .ofs_x = 1, .ofs_y = -1},
    {.bitmap_index = 246, .adv_w = 159, .box_w = 10, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 260, .adv_w = 159, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 270, .adv_w = 146, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 280, .adv_w = 170, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 291, .adv_w = 143, .box_w = 6, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 300, .adv_w = 138, .box_w = 6, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 309, .adv_w = 161, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 320, .adv_w = 171, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 331, .adv_w = 67, .box_w = 1, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 333, .adv_w = 87, .box_w = 3, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 338, .adv_w = 151, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 349, .adv_w = 132, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 359, .adv_w = 225, .box_w = 11, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 375, .adv_w = 180, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 386, .adv_w = 171, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 397, .adv_w = 151, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 407, .adv_w = 171, .box_w = 8, .box_h = 14, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 421, .adv_w = 158, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 431, .adv_w = 144, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 441, .adv_w = 149, .box_w = 9, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 454, .adv_w = 170, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 465, .adv_w = 156, .box_w = 9, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 478, .adv_w = 243, .box_w = 15, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 499, .adv_w = 156, .box_w = 9, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 512, .adv_w = 146, .box_w = 9, .box_h = 11, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 525, .adv_w = 145, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 536, .adv_w = 84, .box_w = 3, .box_h = 15, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 542, .adv_w = 133, .box_w = 8, .box_h = 12, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 554, .adv_w = 84, .box_w = 3, .box_h = 15, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 560, .adv_w = 109, .box_w = 6, .box_h = 4, .ofs_x = 0, .ofs_y = 6},
    {.bitmap_index = 563, .adv_w = 112, .box_w = 7, .box_h = 1, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 564, .adv_w = 81, .box_w = 3, .box_h = 3, .ofs_x = 1, .ofs_y = 9},
    {.bitmap_index = 566, .adv_w = 141, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 573, .adv_w = 146, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 583, .adv_w = 125, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 589, .adv_w = 147, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 599, .adv_w = 137, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 606, .adv_w = 97, .box_w = 5, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 613, .adv_w = 143, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 623, .adv_w = 149, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 633, .adv_w = 63, .box_w = 1, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 635, .adv_w = 64, .box_w = 2, .box_h = 14, .ofs_x = 0, .ofs_y = -3},
    {.bitmap_index = 639, .adv_w = 130, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 649, .adv_w = 76, .box_w = 3, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 654, .adv_w = 224, .box_w = 11, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 665, .adv_w = 149, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 672, .adv_w = 145, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 679, .adv_w = 148, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 689, .adv_w = 146, .box_w = 7, .box_h = 11, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 699, .adv_w = 103, .box_w = 5, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 704, .adv_w = 130, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 710, .adv_w = 98, .box_w = 4, .box_h = 11, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 716, .adv_w = 146, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 722, .adv_w = 136, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 730, .adv_w = 211, .box_w = 13, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 743, .adv_w = 135, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 750, .adv_w = 135, .box_w = 8, .box_h = 11, .ofs_x = 0, .ofs_y = -3},
    {.bitmap_index = 761, .adv_w = 131, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 768, .adv_w = 82, .box_w = 4, .box_h = 15, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 776, .adv_w = 63, .box_w = 1, .box_h = 15, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 778, .adv_w = 82, .box_w = 4, .box_h = 15, .ofs_x = 1, .ofs_y = -3},
    {.bitmap_index = 786, .adv_w = 134, .box_w = 6, .box_h = 2, .ofs_x = 1, .ofs_y = 4}
};

/*---------------------
 *  CHARACTER MAPPING
 *--------------------*/



/*Collect the unicode lists and glyph_id offsets*/
static const lv_font_fmt_txt_cmap_t cmaps[] =
{
    {
        .range_start = 32, .range_length = 95, .glyph_id_start = 1,
        .unicode_list = NULL, .glyph_id_ofs_list = NULL, .list_length = 0, .type = LV_FONT_FMT_TXT_CMAP_FORMAT0_TINY
    }
};

/*-----------------
 *    KERNING
 *----------------*/


/*Pair left and right glyphs for kerning*/
static const uint8_t kern_pair_glyph_ids[] =
{
    1, 3,
    1, 8,
    2, 10,
    2, 62,
    2, 94,
    3, 1,
    3, 13,
    3, 14,
    3, 15,
    3, 16,
    3, 21,
    4, 10,
    4, 62,
    4, 94,
    5, 10,
    5, 62,
    5, 94,
    6, 10,
    6, 62,
    6, 94,
    7, 3,
    7, 8,
    8, 1,
    8, 13,
    8, 14,
    8, 15,
    8, 16,
    8, 21,
    9, 5,
    9, 9,
    9, 92,
    10, 10,
    10, 62,
    10, 94,
    12, 10,
    12, 62,
    12, 94,
    13, 3,
    13, 8,
    13, 18,
    13, 21,
    13, 24,
    14, 3,
    14, 5,
    14, 8,
    14, 18,
    14, 24,
    15, 3,
    15, 8,
    15, 18,
    15, 21,
    15, 24,
    16, 16,
    17, 10,
    17, 62,
    17, 94,
    18, 10,
    18, 62,
    18, 94,
    20, 10,
    20, 62,
    20, 94,
    21, 3,
    21, 5,
    21, 8,
    22, 10,
    22, 62,
    22, 94,
    23, 10,
    23, 62,
    23, 94,
    24, 13,
    24, 14,
    24, 15,
    29, 10,
    29, 62,
    29, 94,
    30, 10,
    30, 62,
    30, 94,
    31, 10,
    31, 62,
    31, 94,
    32, 10,
    32, 62,
    32, 94,
    60, 5,
    60, 9,
    60, 92,
    61, 3,
    61, 8,
    62, 10,
    62, 62,
    62, 94,
    63, 10,
    63, 62,
    63, 94,
    64, 10,
    64, 62,
    64, 94,
    92, 5,
    92, 9,
    92, 92,
    94, 10,
    94, 62,
    94, 94,
    95, 10,
    95, 62,
    95, 94
};

/* Kerning between the respective left and right glyphs
 * 4.4 format which needs to scaled with `kern_scale`*/
static const int8_t kern_pair_values[] =
{
    -3, -3, -5, -2, -1, -3, -27, -16,
    -27, -18, -5, -5, -2, -1, -5, -2,
    -1, -5, -2, -1, -9, -9, -3, -27,
    -16, -27, -18, -5, -7, -10, -4, -10,
    -6, -5, -5, -2, -1, -27, -27, -11,
    -2, -9, -16, -3, -16, -8, -11, -27,
    -27, -11, -2, -9, -25, -5, -2, -1,
    -5, -2, -1, -5, -2, -1, -1, -1,
    -1, -5, -2, -1, -5, -2, -1, -12,
    -5, -12, -5, -2, -1, -5, -2, -1,
    -5, -2, -1, -5, -2, -1, -5, -6,
    -3, -18, -18, -5, -2, -1, -5, -2,
    -1, -5, -2, -1, -3, -5, -3, -5,
    -3, -3, -5, -2, -1
};

/*Collect the kern pair's data in one place*/
static const lv_font_fmt_txt_kern_pair_t kern_pairs =
{
    .glyph_ids = kern_pair_glyph_ids,
    .values = kern_pair_values,
    .pair_cnt = 109,
    .glyph_ids_size = 0
};

/*--------------------
 *  ALL CUSTOM DATA
 *--------------------*/

#if LVGL_VERSION_MAJOR == 8
/*Store all the custom data of the font*/
static  lv_font_fmt_txt_glyph_cache_t cache;
#endif

#if LVGL_VERSION_MAJOR >= 8
static const lv_font_fmt_txt_dsc_t font_dsc = {
#else
static lv_font_fmt_txt_dsc_t font_dsc = {
#endif
    .glyph_bitmap = glyph_bitmap,
    .glyph_dsc = glyph_dsc,
    .cmaps = cmaps,
    .kern_dsc = &kern_pairs,
    .kern_scale = 16,
    .cmap_num = 1,
    .bpp = 1,
    .kern_classes = 0,
    .bitmap_format = 0,
#if LVGL_VERSION_MAJOR == 8
    .cache = &cache
#endif
};



/*-----------------
 *  PUBLIC FONT
 *----------------*/

/*Initialize a public general font descriptor*/
#if LVGL_VERSION_MAJOR >= 8
const lv_font_t ui_font_Font16 = {
#else
lv_font_t ui_font_Font16 = {
#endif
    .get_glyph_dsc = lv_font_get_glyph_dsc_fmt_txt,    /*Function pointer to get glyph's data*/
    .get_glyph_bitmap = lv_font_get_bitmap_fmt_txt,    /*Function pointer to get glyph's bitmap*/
    .line_height = 16,          /*The maximum line height required by the font*/
    .base_line = 3,             /*Baseline measured from the bottom of the line*/
#if !(LVGL_VERSION_MAJOR == 6 && LVGL_VERSION_MINOR == 0)
    .subpx = LV_FONT_SUBPX_NONE,
#endif
#if LV_VERSION_CHECK(7, 4, 0) || LVGL_VERSION_MAJOR >= 8
    .underline_position = -1,
    .underline_thickness = 1,
#endif
    .dsc = &font_dsc,          /*The custom font data. Will be accessed by `get_glyph_bitmap/dsc` */
#if LV_VERSION_CHECK(8, 2, 0) || LVGL_VERSION_MAJOR >= 9
    .fallback = NULL,
#endif
    .user_data = NULL,
};



#endif /*#if UI_FONT_FONT16*/

